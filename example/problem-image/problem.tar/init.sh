#!/bin/sh

service xinetd start
tail -f /dev/null