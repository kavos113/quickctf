#!/bin/sh

cd /home/user
timeout --foreground 60s ./example