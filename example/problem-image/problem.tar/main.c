#include <stdio.h>

int main() {
	printf("hello, server\n");
	return 0;
}